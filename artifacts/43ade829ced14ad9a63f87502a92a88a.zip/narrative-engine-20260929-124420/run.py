"""Run this engine: python run.py info | play | serve | evolve"""
from narrative_runtime.__main__ import main

if __name__ == "__main__":
    main()
