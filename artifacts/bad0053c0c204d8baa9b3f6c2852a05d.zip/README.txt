Adaptive Narrative model bundle containing the active configuration and winning evolved parameters. Upload it in the app to play without evolving again.
