# narrative-engine-20260929-124522: offline Adaptive Narrative engine

An evolved storyteller with its world, ready to run without the studio,
the REST API or an internet connection. Python 3.10+ and the packages in
`requirements.txt` (`pip install -r requirements.txt`) are all it needs.

## Try it

    python run.py info          # what is inside
    python run.py play          # play in the terminal
    python run.py serve         # JSON server on http://127.0.0.1:8765 for any game engine
    python run.py evolve        # keep training offline (adopts a better storyteller)

## Embed it in a Python game

```python
import sys; sys.path.insert(0, "path/to/narrative-engine-20260929-124522")
from narrative_runtime import NarrativeEngine

engine = NarrativeEngine("path/to/narrative-engine-20260929-124522")
game = engine.new_game(profile="player-1", stats_mode="random")   # or stats={...} points
view = game.view()        # location, description, npcs, items, actions, health, mission, stats, ...
while not view["ended"]:
    view = game.choose(view["actions"][0])   # by name or index; view["turn"] is the story text
game.save("slot1.game")   # engine.load_game("slot1.game") continues later
```

## Any other engine (Unity, Godot, Unreal, web): HTTP + JSON

Start `python run.py serve --port 8765` next to the game (or as a sidecar
process), then:

| Request | Body | Returns |
| --- | --- | --- |
| `GET /engine` | | engine information |
| `POST /games` | `{"profile": "p1", "stats_mode": "random"}` | the first view, with `game_id` |
| `GET /games/<id>` | | the current view |
| `POST /games/<id>/choose` | `{"action": "Explore harbor"}` or `{"action": 0}` | the turn text and the new view |
| `GET /games/<id>/transcript` | | the story so far |
| `DELETE /games/<id>` | | ends the session |
| `POST /evolve` | `{"generations": 5}` | offline training summary |

Unity (C#):

```csharp
var request = new UnityWebRequest("http://127.0.0.1:8765/games", "POST");
request.uploadHandler = new UploadHandlerRaw(System.Text.Encoding.UTF8.GetBytes("{\"profile\":\"p1\"}"));
request.downloadHandler = new DownloadHandlerBuffer();
request.SetRequestHeader("Content-Type", "application/json");
yield return request.SendWebRequest();   // request.downloadHandler.text is the view (JSON)
```

Godot (GDScript):

```gdscript
var http = HTTPRequest.new(); add_child(http)
http.request("http://127.0.0.1:8765/games/" + game_id + "/choose",
    ["Content-Type: application/json"], HTTPClient.METHOD_POST, JSON.stringify({"action": 0}))
```

## What is inside

- `engine.json`: the evolved storyteller (genome), its benchmark score, how
  it was learned (history per generation), and a world summary.
- `config/engine.yaml`: the world and all tuning, as it was when exported.
  Edit it to change the world; the storyteller adapts through its traits.
- `data/tag_vectors.json`: the tag vectors used during training, so the engine
  behaves exactly as it did in the studio without any machine-learning
  libraries.
- `saves/`: persistent variables per player profile (created when playing)
  and the learning memory used by `evolve`.
